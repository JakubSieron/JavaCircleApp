
import javax.swing.*;
import java.awt.*;

public class CircleSliderGUI {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CircleSliderGUI().createAndShowGUI());
    }

    private void createAndShowGUI() {
        JFrame frame = new JFrame("Circle Slider App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 500);
        frame.setLayout(new BorderLayout());

        CirclePanel circlePanel = new CirclePanel();
        frame.add(circlePanel, BorderLayout.CENTER);

        ControlPanel controlPanel = new ControlPanel(circlePanel);
        frame.add(controlPanel, BorderLayout.EAST);

        JTextArea infoArea = new JTextArea(2, 20);
        infoArea.setEditable(false);
        circlePanel.setInfoArea(infoArea);
        frame.add(new JScrollPane(infoArea), BorderLayout.SOUTH);

        frame.setVisible(true);
    }
}
