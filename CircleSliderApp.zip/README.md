# Circle Slider App

A simple Java Swing application that allows users to:

- Adjust the size of a circle using a slider
- Change the circle's color using RGB sliders
- See the current diameter in either English or Polish
- Experience real-time GUI updates

## How to Run

1. Import into Eclipse or run with any Java IDE.
2. Make sure you're using JDK 17 or compatible.
3. Run the `CircleSliderGUI` class.

## Structure

- `CircleSliderGUI.java`: Main frame and app launcher
- `CirclePanel.java`: Custom drawing panel
- `ControlPanel.java`: Sliders and language selector

---

Made for a Software Engineering 2 assignment.
